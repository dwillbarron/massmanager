WebSocket for Python (ws4py)
============================

Python library providing an implementation of the WebSocket protocol defined in [RFC 6455](http://tools.ietf.org/html/rfc6455).

Read the [documentation](https://ws4py.readthedocs.org/en/latest/) for more information.

You can also join the [ws4py mailing-list](http://groups.google.com/group/ws4py) to discuss the library.
