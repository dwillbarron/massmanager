.. _credits:

Credits
=======

Many thanks to the pywebsocket and Tornado projects which have provided a the starting point for ws4py.
Thanks also to Jeff Lindsay (progrium) for the initial gevent server support.
A well deserved thank you to Tobias Oberstein for `Autobahn <http://autobahn.ws/>`_ test suite.

Obviously thanks to all the various folks who have provided bug reports and fixes.
